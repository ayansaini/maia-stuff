# University Funds and Needs API

This is a small, local prototype backend for the USC funds app. It generates fictional sample data for development. The records do not represent actual USC funds, gifts, grants, or funding requests.

## What's included

- `generate_data.py` creates 150 synthetic funds and 40 synthetic unfunded needs.
- `data/funds.csv` and `data/needs.csv` are spreadsheet-friendly copies.
- `funds.db` is a SQLite database containing the same records.
- `main.py` serves the data through a FastAPI API.

The generator uses a fixed random seed, so rerunning it produces the same records. It recreates the CSV files and database each time.

## Requirements

Install Python 3.10 or newer. Check your version with `python --version` (on some systems, use `python3 --version`).

## Setup on macOS or Linux

Open a terminal in this folder and run:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python generate_data.py
uvicorn main:app --reload
```

## Setup on Windows PowerShell

Open PowerShell in this folder and run:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
py generate_data.py
uvicorn main:app --reload
```

If PowerShell blocks activating the virtual environment, open Command Prompt and use `.venv\Scripts\activate.bat` instead.

## Try the API

With the server running, open `http://127.0.0.1:8000/docs` for interactive API documentation. You can try the endpoints there without writing a frontend.

- `GET /funds` — list funds. Optional filters: `school`, `type`, and `purpose`.
- `GET /funds/FUND-001` — get one fund by ID.
- `GET /utilization` — get spending and utilization percentages. Optional filter: `school`.
- `GET /needs` — list unfunded needs. Optional filters: `school`, `category`, and `status`.
- `GET /health` — check whether the API and database are available.

Example requests:

```text
http://127.0.0.1:8000/funds
http://127.0.0.1:8000/funds?type=gift
http://127.0.0.1:8000/needs?category=lab_equipment
http://127.0.0.1:8000/utilization
```

The API returns JSON. Purpose tags are arrays in API responses and semicolon-separated text in the CSV files.

## Notes for the frontend developer

The API is configured to allow local frontend development from ports 3000 and 5173. If the frontend runs on a different local origin, add that origin to `allow_origins` in `main.py`.

All sample needs start with `amount_funded` set to 0 and `status` set to `unfunded`. Fund available balance is calculated as `opening_balance + inflows - monthly_spending`. Utilization is monthly spending divided by opening balance plus inflows.
