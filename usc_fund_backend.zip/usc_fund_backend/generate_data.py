"""Generate synthetic USC-style funds and unfunded needs.

The records are fictional examples for a prototype and do not represent real
USC financial accounts or requests.
"""

import csv
import random
import sqlite3
from pathlib import Path


BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
DB_PATH = BASE_DIR / "funds.db"
FUNDS_CSV = DATA_DIR / "funds.csv"
NEEDS_CSV = DATA_DIR / "needs.csv"
SEED = 20261119
REPORTING_MONTH = "2026-10-01"

SCHOOLS = [
    "USC Dornsife College of Letters, Arts and Sciences",
    "USC Marshall School of Business",
    "USC Annenberg School for Communication and Journalism",
    "USC Andrew and Erna Viterbi School of Engineering",
    "USC Gould School of Law",
    "Keck School of Medicine of USC",
    "USC Gayle Garner Roski School of Art and Design",
    "USC Flora L. Thornton School of Music",
]
SCHOOL_LABELS = {
    SCHOOLS[0]: "Dornsife",
    SCHOOLS[1]: "Marshall",
    SCHOOLS[2]: "Annenberg",
    SCHOOLS[3]: "Viterbi",
    SCHOOLS[4]: "Gould",
    SCHOOLS[5]: "Keck",
    SCHOOLS[6]: "Roski",
    SCHOOLS[7]: "Thornton",
}

FUND_FIELDS = [
    "fund_id", "name", "type", "restriction_text", "school",
    "purpose_tags", "reporting_month", "opening_balance", "inflows",
    "monthly_spending", "available_balance", "spend_by_date",
]
NEED_FIELDS = [
    "need_id", "name", "description", "category", "school",
    "purpose_tags", "amount_needed", "amount_funded", "needed_by_date",
    "priority", "status",
]

PURPOSES = {
    "scholarship": {
        "tags": ["scholarship", "undergraduate_support"],
        "examples": [
            "Undergraduate Scholarship Fund",
            "Student Access Scholarship",
            "Need-Based Student Award",
            "First-Generation Student Scholarship",
            "Academic Achievement Scholarship",
        ],
        "restriction": "May be used for scholarships for eligible students.",
    },
    "lab_equipment": {
        "tags": ["lab_equipment", "research_support"],
        "examples": [
            "Teaching Laboratory Equipment Fund",
            "Research Instrumentation Fund",
            "Laboratory Modernization Fund",
            "Scientific Equipment Support Fund",
        ],
        "restriction": "May be used to purchase or maintain laboratory and research equipment.",
    },
    "TA_support": {
        "tags": ["TA_support", "instructional_support"],
        "examples": [
            "Teaching Assistant Support Fund",
            "Undergraduate Course Support Fund",
            "Instructional Staffing Fund",
            "Teaching and Learning Support Fund",
        ],
        "restriction": "May be used for teaching assistant support and instructional needs.",
    },
    "research_support": {
        "tags": ["research_support", "faculty_support"],
        "examples": [
            "Faculty Research Seed Fund",
            "Interdisciplinary Research Fund",
            "Early Career Research Support Fund",
        ],
        "restriction": "May be used to support faculty-led academic research.",
    },
    "student_support": {
        "tags": ["student_support", "undergraduate_support"],
        "examples": [
            "Student Opportunity Fund",
            "Experiential Learning Support Fund",
            "Student Emergency Assistance Fund",
        ],
        "restriction": "May be used for eligible student programs and support.",
    },
}

NEED_TEMPLATES = {
    "scholarship": [
        ("Undergraduate Scholarship Awards", "Provide scholarship support to undergraduate students for the upcoming academic year."),
        ("Need-Based Student Scholarships", "Reduce unmet financial need for eligible students in the school."),
        ("First-Generation Student Awards", "Provide scholarship assistance to first-generation students."),
        ("Student Access Scholarships", "Help students meet education costs through need-based scholarship awards."),
    ],
    "lab_equipment": [
        ("Teaching Lab Equipment Upgrade", "Replace or upgrade equipment used in undergraduate teaching laboratories."),
        ("Research Laboratory Instruments", "Purchase instruments needed for faculty and student research projects."),
        ("Laboratory Safety and Equipment", "Purchase equipment that supports safe, reliable laboratory instruction."),
        ("Shared Research Equipment", "Acquire shared equipment for research teams and academic laboratories."),
    ],
    "TA_support": [
        ("Course Teaching Assistant Support", "Fund teaching assistant hours for a high-enrollment undergraduate course."),
        ("Additional Discussion Section TA", "Support teaching assistant coverage for additional course discussion sections."),
        ("Student Learning Support", "Provide teaching assistant support for student questions, labs, or course projects."),
        ("Instructional Assistant Funding", "Fund instructional assistant support for the next academic term."),
    ],
}


def make_funds(rng: random.Random) -> list[dict]:
    funds = []
    purpose_keys = list(PURPOSES)
    fund_types = ["gift", "grant", "endowment"]

    for index in range(1, 151):
        school = SCHOOLS[(index - 1) % len(SCHOOLS)]
        purpose = purpose_keys[(index - 1) % len(purpose_keys)]
        profile = PURPOSES[purpose]
        fund_type = fund_types[(index - 1) % len(fund_types)]
        base_name = profile["examples"][(index - 1) % len(profile["examples"])]
        name = f"{SCHOOL_LABELS[school]} {base_name} {index:03d}"

        opening_balance = rng.randrange(5000, 250001, 500)
        inflows = rng.choice([0, 0, 2500, 5000, 10000, 15000, 25000])
        max_spending = min(opening_balance + inflows, 45000)
        monthly_spending = rng.randrange(500, max_spending + 1, 500)
        available_balance = opening_balance + inflows - monthly_spending
        spend_by_date = rng.choice([
            "", "", "", "2027-06-30", "2027-12-31", "2028-06-30"
        ])

        tags = list(profile["tags"])
        if school == "USC Dornsife College of Letters, Arts and Sciences":
            tags.append("humanities")
        elif school == "USC Andrew and Erna Viterbi School of Engineering":
            tags.append("engineering")
        elif school == "USC Annenberg School for Communication and Journalism":
            tags.append("communication")

        if fund_type == "endowment":
            restriction = f"Spendable earnings {profile['restriction'][0].lower() + profile['restriction'][1:]}"
        else:
            restriction = profile["restriction"]

        funds.append({
            "fund_id": f"FUND-{index:03d}",
            "name": name,
            "type": fund_type,
            "restriction_text": restriction,
            "school": school,
            "purpose_tags": ";".join(tags),
            "reporting_month": REPORTING_MONTH,
            "opening_balance": opening_balance,
            "inflows": inflows,
            "monthly_spending": monthly_spending,
            "available_balance": available_balance,
            "spend_by_date": spend_by_date,
        })

    return funds


def make_needs(rng: random.Random) -> list[dict]:
    needs = []
    categories = ["scholarship", "lab_equipment", "TA_support"]

    for index in range(1, 41):
        school = SCHOOLS[(index - 1) % len(SCHOOLS)]
        category = categories[(index - 1) % len(categories)]
        name, description = rng.choice(NEED_TEMPLATES[category])
        tags = list(PURPOSES[category]["tags"])
        if school == "USC Dornsife College of Letters, Arts and Sciences":
            tags.append("humanities")
        elif school == "USC Andrew and Erna Viterbi School of Engineering":
            tags.append("engineering")
        elif school == "USC Annenberg School for Communication and Journalism":
            tags.append("communication")

        amount_ranges = {
            "scholarship": (5000, 40000),
            "lab_equipment": (8000, 75000),
            "TA_support": (4000, 25000),
        }
        low, high = amount_ranges[category]
        needed_by = rng.choice(["2027-01-15", "2027-03-01", "2027-06-01", "2027-08-15"])

        needs.append({
            "need_id": f"NEED-{index:03d}",
            "name": f"{SCHOOL_LABELS[school]} {name} {index:03d}",
            "description": description,
            "category": category,
            "school": school,
            "purpose_tags": ";".join(tags),
            "amount_needed": rng.randrange(low, high + 1, 1000),
            "amount_funded": 0,
            "needed_by_date": needed_by,
            "priority": rng.choice(["medium", "medium", "high"]),
            "status": "unfunded",
        })

    return needs


def write_csv(path: Path, fields: list[str], records: list[dict]) -> None:
    with path.open("w", newline="", encoding="utf-8") as csv_file:
        writer = csv.DictWriter(csv_file, fieldnames=fields)
        writer.writeheader()
        writer.writerows(records)


def load_database(funds: list[dict], needs: list[dict]) -> None:
    if DB_PATH.exists():
        DB_PATH.unlink()

    connection = sqlite3.connect(DB_PATH)
    try:
        connection.executescript("""
            CREATE TABLE funds (
                fund_id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                type TEXT NOT NULL,
                restriction_text TEXT NOT NULL,
                school TEXT NOT NULL,
                purpose_tags TEXT NOT NULL,
                reporting_month TEXT NOT NULL,
                opening_balance INTEGER NOT NULL,
                inflows INTEGER NOT NULL,
                monthly_spending INTEGER NOT NULL,
                available_balance INTEGER NOT NULL,
                spend_by_date TEXT
            );

            CREATE TABLE needs (
                need_id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                description TEXT NOT NULL,
                category TEXT NOT NULL,
                school TEXT NOT NULL,
                purpose_tags TEXT NOT NULL,
                amount_needed INTEGER NOT NULL,
                amount_funded INTEGER NOT NULL,
                needed_by_date TEXT,
                priority TEXT NOT NULL,
                status TEXT NOT NULL
            );
        """)

        connection.executemany(
            "INSERT INTO funds VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            [tuple(fund[field] for field in FUND_FIELDS) for fund in funds],
        )
        connection.executemany(
            "INSERT INTO needs VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            [tuple(need[field] for field in NEED_FIELDS) for need in needs],
        )
        connection.commit()
    finally:
        connection.close()


def main() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    rng = random.Random(SEED)
    funds = make_funds(rng)
    needs = make_needs(rng)
    write_csv(FUNDS_CSV, FUND_FIELDS, funds)
    write_csv(NEEDS_CSV, NEED_FIELDS, needs)
    load_database(funds, needs)
    print(f"Created {len(funds)} funds: {FUNDS_CSV}")
    print(f"Created {len(needs)} needs: {NEEDS_CSV}")
    print(f"Loaded both datasets into: {DB_PATH}")


if __name__ == "__main__":
    main()
