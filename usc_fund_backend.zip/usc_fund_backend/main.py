"""FastAPI backend for the synthetic fund and need prototype."""

import os
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator, Optional

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware


BASE_DIR = Path(__file__).resolve().parent
DB_PATH = Path(os.getenv("FUND_DB_PATH", BASE_DIR / "funds.db"))

app = FastAPI(
    title="University Funds and Needs API",
    description="Prototype API backed by fictional sample funds and needs.",
    version="0.1.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",
        "http://127.0.0.1:3000",
        "http://localhost:5173",
        "http://127.0.0.1:5173",
    ],
    allow_credentials=True,
    allow_methods=["GET"],
    allow_headers=["*"],
)


def get_connection() -> sqlite3.Connection:
    if not DB_PATH.exists():
        raise HTTPException(
            status_code=503,
            detail="Database not found. Run `python generate_data.py` first.",
        )
    connection = sqlite3.connect(DB_PATH)
    connection.row_factory = sqlite3.Row
    return connection


@contextmanager
def db_connection() -> Iterator[sqlite3.Connection]:
    connection = get_connection()
    try:
        yield connection
    finally:
        connection.close()


def row_to_record(row: sqlite3.Row) -> dict:
    record = dict(row)
    record["purpose_tags"] = [
        tag for tag in record["purpose_tags"].split(";") if tag
    ]
    return record


@app.get("/")
def home() -> dict:
    return {
        "message": "University Funds and Needs API is running.",
        "docs": "/docs",
        "endpoints": ["/funds", "/utilization", "/needs", "/health"],
    }


@app.get("/health")
def health() -> dict:
    if not DB_PATH.exists():
        return {"status": "ok", "database": "missing; run generate_data.py"}
    return {"status": "ok", "database": "ready"}


@app.get("/funds")
def list_funds(
    school: Optional[str] = Query(default=None, description="Filter by exact school name"),
    fund_type: Optional[str] = Query(default=None, alias="type", description="gift, grant, or endowment"),
    purpose: Optional[str] = Query(default=None, description="Filter by purpose tag"),
) -> dict:
    sql = "SELECT * FROM funds WHERE 1 = 1"
    values: list[str] = []
    if school:
        sql += " AND school = ?"
        values.append(school)
    if fund_type:
        if fund_type not in {"gift", "grant", "endowment"}:
            raise HTTPException(status_code=400, detail="type must be gift, grant, or endowment")
        sql += " AND type = ?"
        values.append(fund_type)
    if purpose:
        sql += " AND (';' || purpose_tags || ';') LIKE ?"
        values.append(f"%;{purpose};%")
    sql += " ORDER BY fund_id"

    with db_connection() as connection:
        records = [row_to_record(row) for row in connection.execute(sql, values).fetchall()]
    return {"count": len(records), "funds": records}


@app.get("/funds/{fund_id}")
def get_fund(fund_id: str) -> dict:
    with db_connection() as connection:
        row = connection.execute("SELECT * FROM funds WHERE fund_id = ?", (fund_id,)).fetchone()
    if row is None:
        raise HTTPException(status_code=404, detail="Fund not found")
    return row_to_record(row)


@app.get("/utilization")
def get_utilization(
    school: Optional[str] = Query(default=None, description="Filter by exact school name"),
) -> dict:
    sql = "SELECT * FROM funds"
    values: list[str] = []
    if school:
        sql += " WHERE school = ?"
        values.append(school)
    sql += " ORDER BY fund_id"

    with db_connection() as connection:
        rows = connection.execute(sql, values).fetchall()

    utilization = []
    for row in rows:
        record = dict(row)
        total_available_this_month = record["opening_balance"] + record["inflows"]
        utilization_rate = (
            round(record["monthly_spending"] / total_available_this_month * 100, 1)
            if total_available_this_month
            else 0.0
        )
        utilization.append({
            "fund_id": record["fund_id"],
            "name": record["name"],
            "school": record["school"],
            "reporting_month": record["reporting_month"],
            "opening_balance": record["opening_balance"],
            "inflows": record["inflows"],
            "monthly_spending": record["monthly_spending"],
            "available_balance": record["available_balance"],
            "utilization_percent": utilization_rate,
        })
    return {"count": len(utilization), "utilization": utilization}


@app.get("/needs")
def list_needs(
    school: Optional[str] = Query(default=None, description="Filter by exact school name"),
    category: Optional[str] = Query(default=None, description="scholarship, lab_equipment, or TA_support"),
    status: Optional[str] = Query(default=None, description="unfunded, partially_funded, or funded"),
) -> dict:
    sql = "SELECT * FROM needs WHERE 1 = 1"
    values: list[str] = []
    if school:
        sql += " AND school = ?"
        values.append(school)
    if category:
        if category not in {"scholarship", "lab_equipment", "TA_support"}:
            raise HTTPException(status_code=400, detail="category must be scholarship, lab_equipment, or TA_support")
        sql += " AND category = ?"
        values.append(category)
    if status:
        if status not in {"unfunded", "partially_funded", "funded"}:
            raise HTTPException(status_code=400, detail="status must be unfunded, partially_funded, or funded")
        sql += " AND status = ?"
        values.append(status)
    sql += " ORDER BY need_id"

    with db_connection() as connection:
        records = [row_to_record(row) for row in connection.execute(sql, values).fetchall()]
    return {"count": len(records), "needs": records}
